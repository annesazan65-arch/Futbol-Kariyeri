# Kariyer Kulübü ⚽ — Futbolcu Kariyer Simülasyonu

## Bilgisayarında çalıştırmak için
1. Node.js kurulu olmalı (18+): https://nodejs.org
2. Terminalde bu klasörde:
   npm install
   npm run dev
3. Açılan http://localhost:5173 adresine git.

## Web sitesi olarak yayınlamak (ücretsiz)
### Vercel (önerilen)
1. https://vercel.com üzerinden ücretsiz hesap aç (GitHub ile giriş yapabilirsin).
2. Bu klasörü bir GitHub reposuna yükle (veya "Add New Project" > "Import" ile zip'i sürükle).
3. Vercel otomatik olarak Vite projesini tanır, "Deploy" de. Birkaç saniyede canlı bir link alırsın.

### Netlify (alternatif)
1. https://app.netlify.com/drop adresine git.
2. Önce terminalde `npm install && npm run build` çalıştır (bir `dist` klasörü oluşur).
3. `dist` klasörünü Netlify Drop sayfasına sürükle bırak. Anında canlı link verir.

## Telefonda "uygulama" gibi kullanmak (PWA)
Site yayına alındıktan sonra telefonunda tarayıcıdan siteyi aç, tarayıcı menüsünden
"Ana Ekrana Ekle" (Add to Home Screen) seçeneğini kullan. Uygulama ikonu gibi açılır.

## Gerçek Android/iOS uygulamasına çevirmek
Siteyi Capacitor (https://capacitorjs.com) ile sarmalayarak App Store / Play Store'a
yüklenebilir gerçek bir uygulamaya dönüştürebilirsin:
   npm install @capacitor/core @capacitor/cli
   npx cap init
   npx cap add android
   npx cap add ios
Bu adımlar için Android Studio / Xcode gerekir.
